// if you wants signs, please see genPOI.py
