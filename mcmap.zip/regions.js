// This is just an example. You can run some scripts to generate regions that
/*
var groupName = "Regions";
var displayName = "Areas";
var world = "top";

markersDB[groupName] = {
	"raw": [
		{
		"strokeColor": "#FF0000",
		"strokeWeight": 2,
		"fill": true,
		"polyline" : [
			{"x": 347, "y": 67, "z": 95},
			{"x": 347, "y": 77, "z": 95},
			{"x": 347, "y": 77, "z": 105},
			{"x": 347, "y": 67, "z": 105},
			{"x": 347, "y": 67, "z": 105}
		]}
	],
	"name": groupName,
	"created": false
}

markers[world].push(
	{
      "groupName": groupName, 
      "icon": "signpost_icon.png", 
      "createInfoWindow": false, 
      "displayName": displayName, 
      "checked": true
	});
*/
